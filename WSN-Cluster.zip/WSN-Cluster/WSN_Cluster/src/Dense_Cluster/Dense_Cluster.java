package Dense_Cluster;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Calendar;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;
import Imbalanced_CLuster.Imbalanced_Cluster;

public class Dense_Cluster {
	public void CLuster(Sensor sensor, Link link, int k, double s, double t) throws ParserConfigurationException, SAXException, IOException, TransformerException
	{
		int m=1;//số cụm
		int n=1;//số lượng sensor trong 1 cụm
		double r=(2*s)/(t+1);
		DecimalFormat df = new DecimalFormat("0.00");
		System.out.println(r);
		System.out.println(df.format(((double)Math.round(r*100)/100)));
		NoteSensor i=sensor.pH;
		NoteSensor j=i.nextNote;
		Dens_Cluster(sensor, link, k, r, i, j, m, n);	
	}
	private void Dens_Cluster(Sensor sensor, Link link, int k, double r, NoteSensor i, NoteSensor j, int m, int n) throws ParserConfigurationException, SAXException, IOException, TransformerException {
		// TODO Auto-generated method stub
		long begin = Calendar.getInstance().getTimeInMillis();
		while((i!=sensor.pT)) //(i!=null)&&
		{
			if(i.flag==0)
			{
				//gom cum cac node xung quanh cua node hien tai
				j=i.nextNote;
				while(j!=null) 
				{
					if(j.flag==0)
					{
						NoteLink a=link.pH;
						while(a!=null)
						{
							if((a.from==i.id)&&(a.to==j.id))//(a.from==i.id)&&(a.to==j.id)
							{
								double d=Math.sqrt(Math.pow(i.x-j.x, 2)+Math.pow(i.y-j.y, 2));
								if(d<r)
								{
									i.flag=m;
									j.flag=m;
									n++;
								}
							}
							a=a.nextNote;
						}
					}j=j.nextNote;
				}
				//gom cum them cac node hang xom
				NoteSensor b, c;
				for(int l=0; l<n/2; l++)
				{
					b=sensor.pH; c=sensor.pH;
					while((b!=sensor.pT)) 
					{
						if(b.flag==m)
						{
							c=i;
								while(c!=null) 
								{
									if(c.flag==0)
									{
										NoteLink a=link.pH;
										while(a!=null)
										{
											if((a.from==b.id)&&(a.to==c.id))
											{
												double d=Math.sqrt(Math.pow(b.x-c.x, 2)+Math.pow(b.y-c.y, 2));
												if(d<r)
												{
													b.flag=m;
													c.flag=m;
													n++;
												}
											} a=a.nextNote;
										}
									}c=c.nextNote;
								} 
						}b=b.nextNote;
					}
				}
				if(n<k)
				{
					NoteSensor b1 =sensor.pH;
					while(b1!=null){
						if(b1.flag==m) b1.flag=0;
						b1=b1.nextNote;
					}
					n=1;
				}else {m++;n=1;}
			}
			i=i.nextNote;
		}
		long end = Calendar.getInstance().getTimeInMillis(); 
		System.out.println("Executed Time Cluster Dense: " + (end - begin)); 
		
		System.out.println("So cum cua Dense_Cluster gom duoc la:  "+ (m-1));
		
		WriteFile wrfile=new WriteFile();
		wrfile.Writefile(sensor, link, 0, m, 1, 1);
		Imbalanced_Cluster imb=new Imbalanced_Cluster();
		imb.Imbalanced_cluster(sensor, link, m, n);
		
	}
}
