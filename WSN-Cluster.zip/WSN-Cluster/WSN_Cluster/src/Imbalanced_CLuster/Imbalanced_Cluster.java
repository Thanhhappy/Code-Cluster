package Imbalanced_CLuster;

import java.io.IOException;
import java.util.Calendar;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.xml.sax.SAXException;

import Dense_Cluster.Link;
import Dense_Cluster.NoteLink;
import Dense_Cluster.NoteSensor;
import Dense_Cluster.Sensor;
import Dense_Cluster.WriteFile;

public class Imbalanced_Cluster {
	public void Imbalanced_cluster(Sensor sensor, Link link, int m, int n) throws ParserConfigurationException, SAXException, IOException, TransformerException {
		// TODO Auto-generated method stub
		long begin = Calendar.getInstance().getTimeInMillis();
		NoteSensor i=sensor.pH;
		NoteSensor j=i.nextNote;
		int m1=m, y=0;
		while((i!=null)&&(i!=sensor.pT)) 
		{
			if((i.flag==0)&&((i.rei/i.sen)>1))
			{
				//gom cum cac node xung quanh cua node hien tai
				j=i.nextNote;
				while(j!=null) 
				{
					if((j.flag==0)&&(((j.rei)/j.sen)>1))
					{
						NoteLink a=link.pH;
						while(a!=null)
						{
							if((a.from==i.id)&&(a.to==j.id))
							{
								i.flag=m;
								j.flag=m;
								n++;y++;
								a=a.nextNote;
							}else a=a.nextNote;
						}
					}j=j.nextNote;
				} i=i.nextNote;
				//gom cum them cac node hang xom
				NoteSensor b, c;
				for(int l=0; l<n/2; l++)
				{
					b=i; c=i;
					while((b!=null)&&(b!=sensor.pT)) 
					{
						if((b.flag==m)&&(b.flag>m1))
						{
							c=i;
								while(c!=null) 
								{
									if((c.flag==0)&&((c.rei/c.sen)>1))
									{
										NoteLink a=link.pH;
										while((a!=null))
										{
											if(((a.from==b.id)&&(a.to==c.id))||((a.from==c.id)&&(a.to==b.id)))
											{
												c.flag=m;
												n++;y++;
												a=a.nextNote;
											}else a=a.nextNote;
										}
									}c=c.nextNote;
								} 
						}b=b.nextNote;
					}
				}
				if(y!=0) {m++;n=1;y=0;}
				else n=1;
			}else i=i.nextNote;
		}
		long end = Calendar.getInstance().getTimeInMillis(); 
		System.out.println("Executed Time Cluster Imbalanced: " + (end - begin));
		System.out.println("So cum cua Imbalanced_Cluster gom duoc la:  "+ (m-m1));
		/*
		i=sensor.pH;
		n=0;
		System.out.println("So cum gom duoc la:  "+ (m-m1));
		for(int i1=m1; i1<m; i1++)
		{
			if(n==0) { System.out.println("Cum "+(m-i1)+": ");n++;}
			while(i!=null)
			{
				if(i.flag==i1)
					System.out.println(i.name);
				i=i.nextNote;
			}
			System.out.print("\n");
			i=sensor.pH;
			n=0;
		}
		*/
		/*
		i=sensor.pH;
		n=0;
		while(i!=null)
		{
			if(i.flag==0)
				n++;
			i=i.nextNote;
		}
		System.out.println("So luong sensor con lai:  "+ n);
		*/
		WriteFile wrfile=new WriteFile();
		wrfile.Writefile(sensor, link, m1, m, 1, 2);
		
		wrfile.Writefile(sensor, link, 0, m, 1, 3);
	}
}
