package Random_sensor;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Random;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class random_sensor {
	public static int[] a=new int[9999];
	public static int[] b=new int[9999];
	public static DecimalFormat df = new DecimalFormat("0.00");
	public static void main(String[] args) throws TransformerException, SAXException, IOException {
		// TODO Auto-generated method stub
		boolean success = (new File("WSN-topology.kwsn")).delete();
	    if (success) {
	        System.out.println("The file has been successfully deleted"); 
	     }
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        File f = new File("WSN-topology.kwsn");
        Document document = createSensor(50);//20:30, 30:40, 50:70, 100:130 
        DOMSource source = new DOMSource(document);
        StreamResult result = new StreamResult(f);
        transformer.transform(source, result);
        System.out.println("Write file successful!!");
    }
	private static Document createSensor(int listsen) throws TransformerConfigurationException, SAXException, IOException{ 
        try { 
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();         
            DocumentBuilder build = factory.newDocumentBuilder();      
            Document doc = build.newDocument();    
            Element wsn = doc.createElement("WSN");         
            doc.appendChild(wsn);
           
            Element nw = doc.createElement("Network");
            nw.setAttribute("NumberOfPackets", "10");
            nw.setAttribute("SensorMaxBufferSize", "5");
            nw.setAttribute("SensorMaxQueueSize", "5");
            nw.setAttribute("ChannelMaxBufferSize", "5");
            wsn.appendChild(nw); 
            
            Element pro = doc.createElement("Process");
            nw.appendChild(pro); 
            
            
            Element sens = doc.createElement("Sensors");         
            pro.appendChild(sens); 
            
            for(int i=1;i<=listsen;i++)
            {
	            Element sen = doc.createElement("Sensor");
	            sen.setAttribute("Name", "Sensor "+i);
	            sen.setAttribute("Init", "True");
	            sen.setAttribute("SType", "3");
	            sen.setAttribute("id", Integer.toString(i));
	            sen.setAttribute("MaxSendingRate", Integer.toString(randInt()));
	            sen.setAttribute("MaxProcessingRate", Integer.toString(randInt()));
	            sen.setAttribute("Energy", "10.0");
	            if(i==1) sen.setAttribute("Token", "1");
	            sens.appendChild(sen); 
	            
	            Element pos = doc.createElement("Position");
	            pos.setAttribute("X", df.format(((double)Math.round(randDouble()*100)/100)));
	            pos.setAttribute("Y", df.format(((double)Math.round(randDouble()*100)/100)));
	            sen.appendChild(pos);
            }
            
            randArray(a, b, listsen);
            Element links = doc.createElement("Links");         
            pro.appendChild(links); 
            for(int i=1;i<a.length;i++)
            {
            	if((a[i]!=0)&&(b[i]!=0))
            	{
				Element link = doc.createElement("Link");
	            link.setAttribute("MaxSendingRate", "3");
	            link.setAttribute("id", a[i]+"_"+b[i]);
	            links.appendChild(link);
	            
	            Element frm = doc.createElement("From");
	            frm.setTextContent("Sensor "+a[i]);
	            link.appendChild(frm); 
	            
	            Element to1 = doc.createElement("To");
	            to1.setTextContent("Sensor "+b[i]);
	            link.appendChild(to1); 
	            
	            Element Isco=doc.createElement("IsConverted");
	            Isco.setTextContent("false");
	            link.appendChild(Isco);
            	}
        	}
            return doc;
            
        }catch(ParserConfigurationException e){ 
            return null; 
        }          
    }
	public static void randArray(int[] a, int[] b, int m)
	{
		for(int i=0; i<(m+200);i++)//tang link
		{
			int x=randInt(m), y=randInt(m), d=0;
			if(x!=y)
			{
				for(int j=0; j<i;j++)
				{
					if((a[j]==x)&&(b[j]==y)) d++;
				}	
			}
			if(d==0) {a[i]=x; b[i]=y;}
			else i--;
		}
	}
	public static int randInt() {
		int min=1, max=15;
        try {
            int range = max - min + 1;
            int randomNum = min + new Random().nextInt(range);
            return randomNum;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }
	public static int randInt(int max) {
		int min=1;
        try {
            int range = max - min + 1;
            int randomNum = min + new Random().nextInt(range);
            return randomNum;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }
	public static double randDouble() {
		float min=0, max=10;
        try {
            double randomNum = min + new Random().nextFloat()*(max-min);
            return randomNum;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

}
