package Dense_Cluster;
public class Link {
	public NoteLink pH;
	public NoteLink pT;
}
