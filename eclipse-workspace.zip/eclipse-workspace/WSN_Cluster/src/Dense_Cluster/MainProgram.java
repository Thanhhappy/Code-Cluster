package Dense_Cluster;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.xml.sax.SAXException;

public class MainProgram {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, TransformerException {
		// TODO Auto-generated method stub
		int k=3;
		
		//double s=1.9, t= 3.7;//0.81
		//double s=1.5, t= 0.7;//1.76
		double s=2.9, t= 1.4;//2.42
		Sensor listsensor=new Sensor();
		Link listlink=new Link();
		ReadFile rdfile=new ReadFile();
		rdfile.Readfile(listsensor);
		rdfile.ReadLink(listlink);
		
		Dense_Cluster den=new Dense_Cluster();
		den.CLuster(listsensor, listlink, k, s, t);
		
	}
}

