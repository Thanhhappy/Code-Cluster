package Dense_Cluster;
public class NoteLink {
	//public String LType;
	//public String CType;
	public String MaxSendingRate;
	//public String CGNLevel;
	//public String ProbabilityPathCongestion;
	public String id;
	public int from;
	public int to;
	public String IsCon;
	public NoteLink nextNote;

}
