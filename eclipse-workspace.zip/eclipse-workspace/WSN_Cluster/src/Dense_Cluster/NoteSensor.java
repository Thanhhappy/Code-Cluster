package Dense_Cluster;
public class NoteSensor {
	public String name;
	public String init;
	public String stype;
	public int id;
	public float sen;
	public float rei;
	public String enery;
	//public String CGNLevel;
	public float x;
	public float y;
	//public float width;
	//public float label_x;
	//public float label_y;
	//public float label_width;
	public int flag;
	public NoteSensor nextNote;
}
