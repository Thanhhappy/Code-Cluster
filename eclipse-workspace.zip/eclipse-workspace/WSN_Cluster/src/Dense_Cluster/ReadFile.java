package Dense_Cluster;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ReadFile {
	public Object Readfile(Sensor List) {
		// TODO Auto-generated method stub
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder build = factory.newDocumentBuilder();
			File fi=new File("WSN//file-kwsn//WSN-topology.kwsn");
			Document document=build.parse(fi);
			// Lay nut goc cua xml
			Element ele=document.getDocumentElement();
			//System.out.println(ele.getNodeName());
			NodeList list=ele.getElementsByTagName("Sensor");
			NodeList list1=ele.getElementsByTagName("Position");
			for (int i = 0; i < list.getLength(); i++) {
				Node node=list.item(i);
				Node node1=list1.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element el = (Element) node;
					Element el1 = (Element) node1;
					if(List.pH==null)
					{
						List.pH=new NoteSensor();
						List.pH.name=el.getAttribute("Name");//
						//System.out.println(el.getAttribute("Name"));
						//List.pH.init=el.getAttribute("Init");
						//List.pH.stype=el.getAttribute("SType");
						List.pH.id=Integer.parseInt(el.getAttribute("id").trim());
						List.pH.sen=Integer.parseInt(el.getAttribute("MaxSendingRate").trim());
						List.pH.rei=Integer.parseInt(el.getAttribute("MaxProcessingRate").trim());
						//System.out.println(el.getAttribute("MaxProcessingRate"));
						//System.out.println(el.getAttribute("MaxSendingRate"));
						//List.pH.Energy=el.getAttribute("Energy");
						List.pH.x=Float.parseFloat(el1.getAttribute("X").trim());
						List.pH.y=Float.parseFloat(el1.getAttribute("Y").trim());
						//System.out.println(List.pH.x+"   "+List.pH.y);
						
						//List.pH.width=Float.parseFloat(el1.getAttribute("Width"));
						//List.pH.label_x=Float.parseFloat(el1.getAttribute("X"));
						//List.pH.label_y=Float.parseFloat(el1.getAttribute("Y"));
						//List.pH.label_width=Float.parseFloat(el1.getAttribute("Width"));
						List.pH.flag=0;
						List.pH.nextNote=null;
						List.pT=List.pH;
					}
					else {
						NoteSensor newnote=new NoteSensor();
						newnote.name=el.getAttribute("Name");//
						//System.out.println(el.getAttribute("Name"));
						//newnote.init=el.getAttribute("Init");
						//newnote.stype=el.getAttribute("SType");
						newnote.id=Integer.parseInt(el.getAttribute("id").trim());
						newnote.sen=Integer.parseInt(el.getAttribute("MaxSendingRate").trim());
						newnote.rei=Integer.parseInt(el.getAttribute("MaxProcessingRate").trim());
						//System.out.println(el.getAttribute("MaxProcessingRate"));
						//System.out.println(el.getAttribute("MaxSendingRate"));
						//newnote.Energy=el.getAttribute("Energy");
						newnote.x=Float.parseFloat(el1.getAttribute("X").trim());
						newnote.y=Float.parseFloat(el1.getAttribute("Y").trim());
						//System.out.println(newnote.x+"   "+newnote.y);
						//newnote.width=Float.parseFloat(el1.getAttribute("Width"));
						//newnote.label_x=Float.parseFloat(el1.getAttribute("X"));
						//newnote.label_y=Float.parseFloat(el1.getAttribute("Y"));
						//newnote.label_width=Float.parseFloat(el1.getAttribute("Width"));
						newnote.flag=0;
						newnote.nextNote=null;
						List.pT.nextNote=newnote;
						List.pT=newnote;
					}
				}
			}
			
		} catch (Exception ex) {
			Logger.getLogger(ReadFile.class.getName()).log(Level.SEVERE, null, ex);
		}
		return List;
	}
	
	public Object ReadLink(Link ListLink) {
		try {
			DocumentBuilderFactory fap = DocumentBuilderFactory.newInstance();
			DocumentBuilder build = fap.newDocumentBuilder();
			File fi=new File("WSN//file-kwsn//WSN-topology.kwsn");
			Document document=build.parse(fi);
			// Lay nut goc cua xml
			int j=1;
			Element ele=document.getDocumentElement();
			NodeList list=ele.getElementsByTagName("Link");
			for (int i = 0; i < list.getLength(); i++) {
				Node node=list.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element el = (Element) node;
					String str=el.getAttribute("id").trim();
					str=str.replaceAll("\\s+", " ");
					int m=(str).indexOf("_");
					if(ListLink.pH==null)
					{
						ListLink.pH=new NoteLink();
						ListLink.pH.from=Integer.parseInt((el.getAttribute("id")).substring(0, m));
						ListLink.pH.to=Integer.parseInt((el.getAttribute("id")).substring(m+1));
						//System.out.println((el.getAttribute("id")).substring(0, m)+"   "+(el.getAttribute("id")).substring(m+1)+"       "+j++);
						ListLink.pH.nextNote=null;
						ListLink.pT=ListLink.pH;
					}
					else {
						NoteLink newnote=new NoteLink();
						newnote.from=Integer.parseInt((el.getAttribute("id")).substring(0, m));
						newnote.to=Integer.parseInt((el.getAttribute("id")).substring(m+1));
						//System.out.println((el.getAttribute("id")).substring(0, m)+"   "+(el.getAttribute("id")).substring(m+1)+"       "+j++);
						newnote.nextNote=null;
						ListLink.pT.nextNote=newnote;
						ListLink.pT=newnote;
					}
			}
			}
		}catch(Exception ex) {
			Logger.getLogger(ReadFile.class.getName()).log(Level.SEVERE, null, ex);
		}
		return ListLink;
	}
		
}
