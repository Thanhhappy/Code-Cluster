package Dense_Cluster;
public class Sensor {
		public NoteSensor pH;
		public NoteSensor pT;
		
}
