package Dense_Cluster;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class WriteFile {
	public void Writefile(Sensor sensor, Link link, int m1, int m, int n, int x) throws ParserConfigurationException, SAXException, IOException, TransformerException
	{
		if(x==1) {
			//System.out.println("-----------------------Dense-Cluster-----------------------");  
			for(int i1=1; i1<m; i1++)
			{
				copyFile(x, n);n++;
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder build = factory.newDocumentBuilder();
				File f=new File("WSN//dense-cluster//WSN-topology.kwsn");
				Document document=build.parse(f);
				Element ele=document.getDocumentElement();
				
					NoteSensor i=sensor.pH;
					while(i!=null)
					{
						if(i.flag!=i1)
						{
							Element sensor1 =(Element) document.getElementsByTagName("Sensors").item(0);
							Element link1 =(Element) document.getElementsByTagName("Links").item(0);
							NodeList listsensor=ele.getElementsByTagName("Sensor");
							NodeList listlink=ele.getElementsByTagName("Link");
							for (int i2 = 0; i2 < listsensor.getLength(); i2++) {
								
								Element el = (Element) listsensor.item(i2);
								//System.out.println(el.getAttribute("Name"));    
								if(el.getAttribute("Name").equals(i.name))//equals(i.name)
								{
									Element sen =(Element) sensor1.getElementsByTagName("Sensor").item(i2);
									sensor1.removeChild(sen);
								}
							}
							for(int j = 0; j < listlink.getLength(); j++)
							{
								Element el1 =(Element) ele.getElementsByTagName("From").item(j);
								Element el2 =(Element) ele.getElementsByTagName("To").item(j);
								//System.out.println(el1.getTextContent() +"  "+el2.getTextContent());
								String str=el1.getTextContent().trim();
								str=str.replaceAll("\\s+", " ");
								String str1=el2.getTextContent().trim();
								str1=str1.replaceAll("\\s+", " ");
								//System.out.println("-----------------"+str +"  "+str1);
								if((str.equals(i.name))||(str1.equals(i.name)))//equals(i.name)
								{
									//System.out.println(el1.getTextContent() +"  "+el2.getTextContent()); 
									Element lin =(Element) link1.getElementsByTagName("Link").item(j);
									link1.removeChild(lin);
									j--;
								}
							}//System.out.println("-----------------");
						}
						i=i.nextNote;
					}
					TransformerFactory transformerFactory = TransformerFactory.newInstance();
			        Transformer transformer = transformerFactory.newTransformer();
			 
			        DOMSource source = new DOMSource(document);
			        StreamResult result = new StreamResult(f);
			        transformer.transform(source, result);
			        
					File oldfile = new File("WSN//dense-cluster//WSN-topology.kwsn");
					String str = "Cluster"+i1+".kwsn";
					File newfile = new File("WSN//dense-cluster//"+str);
					oldfile.renameTo(newfile);
					/*
					if(oldfile.renameTo(newfile)){
						System.out.println("Rename succesful");
					}else{
						System.out.println("Rename failed");
					}
					System.out.println();
					*/
		}
		}else if(x==2){
			//System.out.println("-----------------------Imbalanced-Cluster-----------------------");
			for(int i1=m1; i1<m; i1++)
			{
				copyFile(x, n);n++;
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder build = factory.newDocumentBuilder();
				File f=new File("WSN//imbalanced-cluster//WSN-topology.kwsn");
				Document document=build.parse(f);
				Element ele=document.getDocumentElement();
				
					NoteSensor i=sensor.pH;
					while(i!=null)
					{
						if(i.flag!=i1)
						{
							Element sensor1 =(Element) document.getElementsByTagName("Sensors").item(0);
							Element link1 =(Element) document.getElementsByTagName("Links").item(0);
							NodeList listsensor=ele.getElementsByTagName("Sensor");
							NodeList listlink=ele.getElementsByTagName("Link");
							for (int i2 = 0; i2 < listsensor.getLength(); i2++) {
								
								Element el = (Element) listsensor.item(i2);
								//System.out.println(el.getAttribute("Name"));    
								if(el.getAttribute("Name").equals(i.name))//equals(i.name)
								{
									Element sen =(Element) sensor1.getElementsByTagName("Sensor").item(i2);
									sensor1.removeChild(sen);
								}
							}
							for(int j = 0; j < listlink.getLength(); j++)
							{
								Element el1 =(Element) ele.getElementsByTagName("From").item(j);
								Element el2 =(Element) ele.getElementsByTagName("To").item(j);
								//System.out.println(el1.getTextContent());
								String str=el1.getTextContent().trim();
								str=str.replaceAll("\\s+", " ");
								String str1=el2.getTextContent().trim();
								str1=str1.replaceAll("\\s+", " ");
								if((str.equals(i.name))||(str1.equals(i.name)))//equals(i.name)
								{
									//System.out.println(el1.getTextContent() +"  "+el2.getTextContent()); 
									Element lin =(Element) link1.getElementsByTagName("Link").item(j);
									link1.removeChild(lin);
								}
							}//System.out.println("-----------------");
						}
						i=i.nextNote;
					}
					TransformerFactory transformerFactory = TransformerFactory.newInstance();
			        Transformer transformer = transformerFactory.newTransformer();
			 
			        DOMSource source = new DOMSource(document);
			        StreamResult result = new StreamResult(f);
			        transformer.transform(source, result);
			        
					File oldfile = new File("WSN//imbalanced-cluster//WSN-topology.kwsn");
					String str = "Cluster"+(i1-m1+1)+".kwsn";
					File newfile = new File("WSN//imbalanced-cluster//"+str);
					oldfile.renameTo(newfile);
					/*
					if(oldfile.renameTo(newfile)){
						System.out.println("Rename succesful");
					}else{
						System.out.println("Rename failed");
					}
					System.out.println();
					*/
		}
		}else if(x==3) {
			//System.out.println("-----------------------Abandoned-Cluster-----------------------");
			copyFile(x, n);n++;
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder build = factory.newDocumentBuilder();
			File f=new File("WSN//abandoned-sensor//WSN-topology.kwsn");
			Document document=build.parse(f);
			Element ele=document.getDocumentElement();
			
				NoteSensor i=sensor.pH;
				while(i!=null)
				{
					if(i.flag>0)
					{
						Element sensor1 =(Element) document.getElementsByTagName("Sensors").item(0);
						Element link1 =(Element) document.getElementsByTagName("Links").item(0);
						NodeList listsensor=ele.getElementsByTagName("Sensor");
						NodeList listlink=ele.getElementsByTagName("Link");
						for (int i2 = 0; i2 < listsensor.getLength(); i2++) {
							
							Element el = (Element) listsensor.item(i2);
							//System.out.println(el.getAttribute("Name"));    
							if(el.getAttribute("Name").equals(i.name))//equals(i.name)
							{
								Element sen =(Element) sensor1.getElementsByTagName("Sensor").item(i2);
								sensor1.removeChild(sen);
							}
						}
						for(int j = 0; j < listlink.getLength(); j++)
						{
							Element el1 =(Element) ele.getElementsByTagName("From").item(j);
							Element el2 =(Element) ele.getElementsByTagName("To").item(j);
							//System.out.println(el1.getTextContent());
							String str=el1.getTextContent().trim();
							str=str.replaceAll("\\s+", " ");
							String str1=el2.getTextContent().trim();
							str1=str1.replaceAll("\\s+", " ");
							if((str.equals(i.name))||(str1.equals(i.name)))//equals(i.name)
							{
								//System.out.println(el1.getTextContent() +"  "+el2.getTextContent()); 
								Element lin =(Element) link1.getElementsByTagName("Link").item(j);
								link1.removeChild(lin);
							}
						}//System.out.println("-----------------");
					}
					i=i.nextNote;
				}
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
		        Transformer transformer = transformerFactory.newTransformer();
		 
		        DOMSource source = new DOMSource(document);
		        StreamResult result = new StreamResult(f);
		        transformer.transform(source, result);
		        System.out.println();
		}
	}
	
    public boolean copyFile(int x, int y) throws FileNotFoundException, IOException {
    	if(x==1) {
    		if(y==1) {boolean success = deleteDir(new File("WSN//dense-cluster"));
    		//if (success) {System.out.println("The folder has been successfully deleted!");}
    		}
    		File file = new File("WSN//dense-cluster");
            if (!file.exists()) {
            	file.mkdir();
            }
	//        file source
	        File sourceFile = new File("WSN//file-kwsn//WSN-topology.kwsn");
	//        file dest
	        
	        File destFile = new File("WSN//dense-cluster//WSN-topology.kwsn");
	//        kiem tra file source co ton tai khong
	        if (sourceFile.exists()) {
	        	@SuppressWarnings("resource")
				FileInputStream inputfile = new FileInputStream(sourceFile);
	        	FileOutputStream outputfile = new FileOutputStream(destFile);
	        	
	            FileChannel sourceChannel = inputfile.getChannel();
				FileChannel destinationChannel = outputfile.getChannel();
				destinationChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
				outputfile.close();
	            outputfile.close();
				
	            //System.out.println("copy successful!");
	            return true;
	        } else {
	            //System.out.println("file not to exist!");
	            return false;
	        }
    	}else if(x==2) {
    		if(y==1) {boolean success = deleteDir(new File("WSN//imbalanced-cluster"));
    		//if (success) {System.out.println("The folder has been successfully deleted!");}
    		}
    		File file = new File("WSN//imbalanced-cluster");
    		if (!file.exists()) {
            	file.mkdir();
            }
	//        file source
	        File sourceFile = new File("WSN//file-kwsn//WSN-topology.kwsn");
	//        file dest
	        
	        File destFile = new File("WSN//imbalanced-cluster//WSN-topology.kwsn");
	//        kiem tra file source co ton tai khong
	        if (sourceFile.exists()) {
	        	@SuppressWarnings("resource")
				FileInputStream inputfile = new FileInputStream(sourceFile);
	        	FileOutputStream outputfile = new FileOutputStream(destFile);
	        	
	            FileChannel sourceChannel = inputfile.getChannel();
				FileChannel destinationChannel = outputfile.getChannel();
				destinationChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
				outputfile.close();
	            outputfile.close();
				
	            //System.out.println("copy successful!");
	            return true;
	        } else {
	            //System.out.println("file not to exist!");
	            return false;
	        }
    	} else if(x==3) {
    		if(y==1) {boolean success = deleteDir(new File("WSN//abandoned-sensor"));
    		//if (success) {System.out.println("The folder has been successfully deleted!");}
    		}
    		File file = new File("WSN//abandoned-sensor");
    		if (!file.exists()) {
            	file.mkdir();
            }
	//        file source
	        File sourceFile = new File("WSN//file-kwsn//WSN-topology.kwsn");
	//        file dest
	        
	        File destFile = new File("WSN//abandoned-sensor//WSN-topology.kwsn");
	//        kiem tra file source co ton tai khong
	        if (sourceFile.exists()) {
	        	@SuppressWarnings("resource")
				FileInputStream inputfile = new FileInputStream(sourceFile);
	        	FileOutputStream outputfile = new FileOutputStream(destFile);
	        	
	            FileChannel sourceChannel = inputfile.getChannel();
				FileChannel destinationChannel = outputfile.getChannel();
				destinationChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
				outputfile.close();
	            outputfile.close();
				
	            //System.out.println("copy successful!");
	            return true;
	        } else {
	            //System.out.println("file not to exist!");
	            return false;
	        }
    	}else return false;
		//return false;
    }
    public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
           String[] children = dir.list();
           for (int i = 0; i < children.length; i++) {
              boolean success = deleteDir (new File(dir, children[i]));
              if (!success) {
                 return false;
              }
           }
        }
        return dir.delete();
    }

}
